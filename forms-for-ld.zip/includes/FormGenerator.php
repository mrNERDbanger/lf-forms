<?php
namespace GFC;

class FormGenerator {
    public function convert_gravity_forms_json($json_data) {
        $form_data = json_decode($json_data, true);
        
        foreach ($form_data as $form_id => $form_details) {
            $form_html = $this->generate_form_html($form_details['fields']);
            
            $new_form_post = [
                'post_title' => $form_details['title'] ?? 'Untitled Form',
                'post_type' => 'gfc_form',
                'post_status' => 'publish',
                'meta_input' => [
                    'original_form_id' => $form_id,
                    'form_html' => $form_html
                ]
            ];

            wp_insert_post($new_form_post);
        }
    }

    public function generate_form_html($fields) {
        $form_html = "<form method='post' class='gfc-form' enctype='multipart/form-data'>\n";
        $form_html .= wp_nonce_field('gfc_submission', 'gfc_nonce', true, false);
        $form_html .= "<input type='hidden' name='action' value='submit_converted_form'>\n";
        
        foreach ($fields as $field) {
            $field_id = $field['id'];
            $label = $field['label'] ?? '';
            $required = !empty($field['required']) ? 'required' : '';
            
            $form_html .= "<div class='form-field'>\n";
            
            switch ($field['type']) {
                case 'email':
                    $form_html .= $this->generate_email_input($field_id, $label, $required);
                    break;
                    
                case 'phone':
                    $form_html .= $this->generate_phone_input($field_id, $label, $required);
                    break;
                    
                case 'date':
                    $form_html .= $this->generate_date_input($field_id, $label, $required);
                    break;
                    
                case 'time':
                    $form_html .= $this->generate_time_input($field_id, $label, $required);
                    break;
                    
                case 'url':
                    $form_html .= $this->generate_url_input($field_id, $label, $required);
                    break;
                    
                case 'name':
                    $form_html .= $this->generate_name_input($field_id, $label, $required);
                    break;
                    
                case 'address':
                    $form_html .= $this->generate_address_input($field_id, $label, $required);
                    break;
                    
                case 'username':
                    $form_html .= $this->generate_username_input($field_id, $label, $required);
                    break;
                    
                case 'password':
                    $form_html .= $this->generate_password_input($field_id, $label, $required);
                    break;
                    
                case 'file':
                    $form_html .= $this->generate_file_upload($field_id, $label, $required);
                    break;
                    
                case 'consent':
                    $form_html .= $this->generate_consent_field($field_id, $label, $required);
                    break;
                    
                case 'chained_select':
                    $options = $field['options'] ?? array();
                    $form_html .= $this->generate_chained_select($field_id, $label, $options, $required);
                    break;
                    
                case 'quiz':
                    $question = $field['question'] ?? array();
                    $form_html .= $this->generate_quiz_field($field_id, $label, $question, $required);
                    break;
                    
                case 'survey':
                    $questions = $field['questions'] ?? array();
                    $form_html .= $this->generate_survey_field($field_id, $label, $questions, $required);
                    break;
                    
                case 'paragraph':
                    $form_html .= $this->generate_paragraph_text($field_id, $label, $required);
                    break;
                    
                case 'dropdown':
                    $choices = $field['choices'] ?? array();
                    $form_html .= $this->generate_dropdown($field_id, $label, $choices, $required);
                    break;
                    
                case 'list':
                    $columns = $field['columns'] ?? array();
                    $form_html .= $this->generate_list_input($field_id, $label, $columns, $required);
                    break;
                    
                case 'multiselect':
                    $choices = $field['choices'] ?? array();
                    $form_html .= $this->generate_multiselect($field_id, $label, $choices, $required);
                    break;
                    
                case 'number':
                    $form_html .= $this->generate_number_input($field_id, $label, $required);
                    break;
                    
                case 'captcha':
                    $form_html .= $this->generate_captcha();
                    break;
                    
                case 'html':
                    $form_html .= $this->generate_html_field($field['content'] ?? '');
                    break;
                    
                case 'section':
                    $form_html .= $this->generate_section_break($label);
                    break;
                    
                case 'pagebreak':
                    $form_html .= $this->generate_page_break();
                    break;
                    
                case 'radio':
                    $choices = $field['choices'] ?? array();
                    $form_html .= $this->generate_radio($field_id, $label, $choices, $required);
                    break;
                    
                case 'checkbox':
                    $choices = $field['choices'] ?? array();
                    $form_html .= $this->generate_checkboxes($field_id, $label, $choices, $required);
                    break;
                    
                case 'hidden':
                    $default_value = $field['default_value'] ?? '';
                    $form_html .= $this->generate_hidden_input($field_id, $default_value);
                    break;
                    
                default:
                    $form_html .= $this->generate_text_input($field_id, $label, $required);
                    break;
            }
            
            $form_html .= "</div>\n";
        }

        $form_html .= "<div class='form-submit'>\n";
        $form_html .= "  <button type='submit' class='gfc-submit'>Submit</button>\n";
        $form_html .= "</div>\n";
        $form_html .= "</form>";
        
        return $form_html;
    }

    // Include all the field generation methods here...
    [Previous field generation methods go here]
}