<?php
namespace GFC;

class Setup {
    public static function activate() {
        // Create necessary roles
        add_role('mentor', 'Mentor', [
            'read' => true,
            'view_submissions' => true
        ]);
        
        add_role('big_bird', 'Big Bird', [
            'read' => true,
            'view_submissions' => true
        ]);
        
        // Create upload directory for PDFs
        $upload_dir = wp_upload_dir();
        wp_mkdir_p($upload_dir['basedir'] . '/form-submissions');
        
        // Create database tables if needed
        self::create_tables();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public static function deactivate() {
        // Remove roles
        remove_role('mentor');
        remove_role('big_bird');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    private static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}form_submissions (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            form_id bigint(20) NOT NULL,
            user_id bigint(20) NOT NULL,
            submission_data longtext NOT NULL,
            pdf_path varchar(255) DEFAULT NULL,
            date_created datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY form_id (form_id),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
} 